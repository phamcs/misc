#!/bin/bash
path="/srv/remotemount/N4S252/REPOS/rancher"
  cd $path
  disable_harbor_proxy
  ./rancher-load-images.sh -l rancher-base-images.txt -i rancher-base-images.tar.gz -s index.docker.io -r harbor.superasian.net > /root/push_results.log 2>&1
  enable_harbor_proxy
exit 0;
