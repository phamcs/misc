#!/bin/bash
versions=("2.10.0" "2.10.1" "2.10.2" "2.10.3" "2.11.0" "2.11.1" "2.11.2" "2.11.3" "2.12.0" "2.12.1" "2.12.2" "2.12.3" "2.13.0" "2.13.1" "2.13.2" "2.13.3" "2.14.0" "2.14.1" "2.14.2")
path="/srv/remotemount/DSM722i52400/archive/rancher/"
    cd $path
    /usr/local/bin/disable_harbor_proxy
    for version in ${versions[@]}; do
        ./rancher-load-images.sh -l rancher-images-$version.txt -s index.docker.io -r harbor.superasian.net > push_results.log 2>&1
    done
    /usr/local/bin/enable_harbor_proxy
exit 0;
