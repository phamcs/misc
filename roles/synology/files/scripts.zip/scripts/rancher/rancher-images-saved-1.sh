#!/bin/bash
versions=("2.14.0")
path="/srv/remotemount/S7Q8300/scripts/rancher/"
    cd $path
    for version in ${versions[@]}; do
        ./rancher-save-images.sh -l rancher-images-$version.txt -s index.docker.io -i rancher-images-$version.tar.gz > save_results.log 2>&1
    done
exit 0;
