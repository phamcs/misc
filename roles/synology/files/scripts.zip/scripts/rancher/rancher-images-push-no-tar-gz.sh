#!/bin/bash
versions=("2.14.0")
path="/srv/remotemount/S7Q8300/scripts/rancher/"
    cd $path
    /usr/local/bin/disable_harbor_proxy
    for version in ${versions[@]}; do
        ./rancher-load-images.sh -l rancher-images-$version.txt -s index.docker.io -r harbor.superasian.net > push_results.log 2>&1
    done
    /usr/local/bin/enable_harbor_proxy
exit 0;
