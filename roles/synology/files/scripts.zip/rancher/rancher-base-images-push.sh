#!/bin/bash
path="/srv/dev-disk-by-uuid-2a48735c-5151-4a6d-a26f-4265b4fd99fe/REPOS/rancher"
  cd $path
  disable_harbor_proxy
  ./rancher-load-images.sh -l rancher-base-images.txt -i rancher-base-images.tar.gz -s index.docker.io -r harbor.superasian.net > push_results.log 2>&1
  enable_harbor_proxy
exit 0;
