#!/bin/bash
versions=("2.10.0" "2.10.1" "2.10.2" "2.10.3" "2.11.0" "2.11.1" "2.11.2" "2.11.3" "2.12.0" "2.12.1" "2.12.2" "2.12.3" "2.13.0" "2.13.1" "2.13.2" "2.13.3")
path="/srv/remotemount/S7Q8300/scripts/rancher/"
    cd $path
    for version in ${versions[@]}; do
        ./rancher-save-images.sh -l rancher-images-$version.txt -s index.docker.io -i rancher-images-$version.tar.gz > save_results.log 2>&1
    done
exit 0;
