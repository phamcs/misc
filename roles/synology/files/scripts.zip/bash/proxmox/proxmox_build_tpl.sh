#!/bin/bash

imageURL=https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img
imageName="jammy-server-cloudimg-amd64.img"
volumeName="local-zfs"
vmid="9000"
templateName="jammy-tpl"
tmp_cores="2"
tmp_memory="2048"
rootPasswd="Letmein123"
cpuTypeRequired="kvm64"

apt update && apt install libguestfs-tools -y
wget -O $imageName $imageURL
qm destroy $vmid
virt-customize -a $imageName --install qemu-guest-agent,openssh-server,python3
virt-customize -a $imageName --root-password password:$rootPasswd
qm create $vmid --name $templateName --memory $tmp_memory --cores $tmp_cores --net0 virtio,bridge=vmbr0
qm importdisk $vmid $imageName $volumeName
qm set $vmid --scsihw virtio-scsi-pci --virtio0 $volumeName:vm-$vmid-disk-0
qm set $vmid --boot c --bootdisk virtio0
qm set $vmid --ide2 $volumeName:cloudinit
qm set $vmid --serial0 socket --vga serial0
qm set $vmid --cicustom "user=local:snippets/$vmid.yaml"
qm set $vmid --sshkeys <(echo "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIIUPEI0LzEyxy6Msj53s4L05ENvHSCQ2mATU34O5Srdo phamcs@iMac27-32G.local")
qm set $vmid --cpu cputype=$cpuTypeRequired
qm template $vmid
rm -f $imageName