#!/bin/bash
repos=("apache" "artifactory" "bitnami" "debian" "gitlab" "gitlab-runner" "gitlab-runner-helper" "httpd" "nginx" "postgres" "rockylinux" "ubuntu")
    ## Disable proxy for push
    FILE="/usr/local/bin/disable_registry_proxy"
    if [ -x "$FILE" ]; then
        ./$FILE
    else
        echo "$FILE does not exist. Uploading registry without disabling proxy may cause push failure."
    fi
    for repo in ${repos[@]}; do
        ./$repo
    done
    ## Enable proxy after done
    FILE="/usr/local/bin/enable_registry_proxy"
    if [ -x "$FILE" ]; then
        ./$FILE
    else
        echo "$FILE does not exist. Please check if the proxy is properly enabled after push."
    fi
exit 0;
