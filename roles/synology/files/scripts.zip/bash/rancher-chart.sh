#!/bin/bash
versions=("2.9.2" "2.9.3" "2.10.0" "2.10.1" "2.10.2" "2.10.3" "2.11.1" "2.11.2" "2.11.3" "2.12.1" "2.12.2" "2.13.1" "2.13.2")
    for version in ${versions[@]}; do
        helm push ~/Projects/helm/rancher-$version.tgz oci://harbor.superasian.net/charts
    done
exit 0;
