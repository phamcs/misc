#!/bin/bash
path="/srv/remotemount/S7Q8300/apps/rancher"
  $path/rancher-load-images.sh -l $path/rancher-base-images.txt -i $path/rancher-base-images.tar.gz -s index.docker.io -r harbor.superasian.net > $path/rancher-base-images.log 2>&1
exit 0;