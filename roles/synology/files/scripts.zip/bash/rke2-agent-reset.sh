#!/bin/bash
rke2-killall.sh
rke2-uninstall.sh
mkdir -p /etc/rancher/rke2
cp rancher/* /etc/rancher/rke2/
curl -sfL https://get.rke2.io | INSTALL_RKE2_CHANNEL=stable INSTALL_RKE2_VERSION="v1.32.8+rke2r1" INSTALL_RKE2_TYPE="agent" sh -
systemctl enable rke2-agent
systemctl start rke2-agent